<?php

use CodeIgniter\Router\RouteCollection;
use App\Controllers\Pages;

/**
 * @var RouteCollection $routes
 */

$routes->get('/', 'Home::index');
$routes->get('/Menu', 'Home::menu');

//Pelanggan
$routes->get('/Pelanggan', 'Pelangganku::index');
$routes->get('/isi-data', 'Pelangganku::isi');
$routes->post('save', 'Pelangganku::save');

//Update Delete Pelanggan
$routes->get('ubah/(:num)', 'Pelangganku::ubah/$1');
$routes->get('/delete/(:num)', 'Pelangganku::delete/$1');
$routes->post('update/(:num)', 'Pelangganku::update/$1');

//Pesanan
$routes->get('Pesan', 'Pesanan::index');
$routes->get('/isi-data-pesan', 'Pesanan::isi');
$routes->post('save-pesanan', 'Pesanan::save');

//Update Delete Pesanan
$routes->get('ubah-pesanan/(:num)', 'Pesanan::ubah/$1');
$routes->get('delete-pesanan/(:num)', 'Pesanan::delete/$1');
$routes->post('update-pesanan/(:num)', 'Pesanan::update/$1');
