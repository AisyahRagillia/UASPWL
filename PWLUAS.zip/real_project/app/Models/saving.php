<?php

namespace App\Models;

use CodeIgniter\Model;

class saving extends Model
{
    protected $table = 'pelanggan'; // Nama tabel database

    protected $allowedFields = ['nama', 'email', 'telepon', 'alamat']; // Kolom-kolom yang dapat diisi

    public function insertCustomer($data)
    {
        return $this->insert($data); // Fungsi untuk memasukkan data customer ke dalam tabel
    }
}
