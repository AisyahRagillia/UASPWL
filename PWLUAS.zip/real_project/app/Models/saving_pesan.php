<?php

namespace App\Models;

use CodeIgniter\Model;

class saving_pesan extends Model
{
    protected $table = 'pesanan'; // Nama tabel database

    protected $allowedFields = ['id_pesanan', 'tgl_pesanan', 'status_pesanan', 'id_pelanggan']; // Kolom-kolom yang dapat diisi

    public function insertIn($data)
    {
        return $this->insert($data); // Fungsi untuk memasukkan data customer ke dalam tabel
    }
}
