<?php

namespace app\Models;

use CodeIgniter\Model;

class get_pesanan extends Model
{
    protected $table = 'pesanan';
    protected $primaryKey = 'id_pesanan';
    protected $allowedFields = ['tgl_pesanan', 'status_pesanan', 'id_pelanggan'];

    public function getPesanan($id = null)
    {
        if ($id === null) {
            return $this->select('pesanan.*, pelanggan.nama, pelanggan.telepon')
                ->join('pelanggan', 'pesanan.id_pelanggan = pelanggan.id_pelanggan')
                ->findAll();
        }
        return $this->find($id);
    }
}
