<?php

namespace app\Models;

use CodeIgniter\Model;

class get_menu extends Model
{
    public function getmakan()
    {
        $query = $this->db->query("SELECT * FROM menu");

        return $query->getResult();
    }
}
