<?php

namespace app\Models;

use CodeIgniter\Model;

class get_pelanggan extends Model
{
    protected $table = 'pelanggan';
    protected $primaryKey = 'id_pelanggan';
    protected $allowedFields = ['nama', 'email', 'telepon', 'alamat'];

    public function getpelanggan($id = null)
    {
        if ($id === null) {
            return $this->findAll();
        }
        return $this->find($id);
    }
}
