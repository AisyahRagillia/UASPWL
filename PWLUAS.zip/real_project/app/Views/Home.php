<div class="container-fluid full-height center-content bg-image">
    <div class="vertical-buttons text-center">
        <a type="button" class="btn btn-secondary pr-5 pl-5" href="/Menu">Menu</a>
        <a type="button" class="btn btn-secondary mt-5 pr-5 pl-5" href="/Pesan">Data Pesanan</a>
        <a type="button" class="btn btn-secondary mt-5 pr-5 pl-5" href="/Pelanggan">Data Pelanggan</a>
    </div>
</div>