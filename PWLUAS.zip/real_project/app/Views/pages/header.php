<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Projek Akhir</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        .full-height {
            height: 100vh;
        }

        .center-content {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .vertical-buttons {
            display: flex;
            flex-direction: column;
        }

        .vertical-buttons .btn {
            margin: 5px 0;
            /* Margin atas dan bawah untuk memberi ruang antar tombol */
        }

        .bg-image {
            background-image: url('bgmasak.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 100vh;
            /* Adjust height as needed */
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
        }

        .bg-costume1 {
            background-color: rgb(0, 0, 0);
        }

        body {
            background-image: url('https://1.bp.blogspot.com/-AIWZWmPoQI0/VonXdp_iVEI/AAAAAAAAAlQ/qhdNQ-ETkl0/s1600/26876245-Fresh-ingredients-for-cooking-pasta-tomato-cucumber-mushroom-and-spices-over-wooden-table-background-Stock-Photo.jpg');
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>
</head>

<body>
    <div class="navy">
        <nav class="navbar navbar-expand-lg bg-secondary">
            <div class="container-fluid">
                <div class="container center-content">
                    <h3>Reservasi Makanan dan Minuman</h3>
                </div>
            </div>
        </nav>
    </div>