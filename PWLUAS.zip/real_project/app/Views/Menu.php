<h1 class="center-content" style="color: white;">Menu Pages</h1>
<table class="table table-striped table-dark table-hover">
    <tr>
        <th>No</th>
        <th>Nama Makanan</th>
        <th>Deskripsi</th>
        <th>Harga</th>
        <th>Kategori</th>
    </tr>
    <?php $no = 1;
    foreach ($dataMakan as $row) : ?>
        <tr>
            <td><?= $no++; ?></td>
            <td><?= $row->nama_menu; ?></td>
            <td><?= $row->deskripsi; ?></td>
            <td><?= $row->harga; ?></td>
            <td><?= $row->kategori; ?></td>
        </tr>
    <?php endforeach ?>
</table>
<div>
    <div class="vertical-buttons text-center">
        <a type="button" class="btn btn-secondary" href="/Pesan">Data Pesanan</a>
        <a type="button" class="btn btn-secondary" href="/Pelanggan">Data Pelanggan</a>
    </div>
</div>