<div class="container mt-5">
    <h1 class="mb-4" style="color: aliceblue; text-align: center;">Buat Pesanan Baru</h1>
    <?php if (session()->getFlashdata('message')) : ?>
        <div class="alert alert-success" role="alert">
            <?= session()->getFlashdata('message') ?>
        </div>
    <?php endif; ?>

    <form action="<?= base_url('update-pesanan/' . $row['id_pesanan']) ?>" method="post">

        <div class="form-group">
            <label for="tanggal_pemesanan">Tanggal Pemesanan:</label>
            <input type="date" name="tanggal_pemesanan" class="form-control" value="<?= $row['tgl_pesanan'] ?>" required>
        </div>

        <div class="form-group">
            <label for="status_pesanan">Status Pesanan:</label>
            <select name="status_pesanan" class="form-control" required>
                <option value="" disabled selected>--Pilih Pelanggan--</option>
                <option value="Sudah Selesai">Sudah Selesai</option>
                <option value="Belum Selesai">Belum Selesai</option>
            </select>
        </div>

        <div class="form-group">
            <label for="id_pelanggan">Nama Pelanggan:</label>
            <select name="id_pelanggan" class="form-control" required>
                <option value="" disabled selected>--Pilih Pelanggan--</option>
                <?php foreach ($dataPesanan as $pel) : ?>
                    <option value="<?= $pel['id_pelanggan'] ?>"><?= $pel['nama'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
</div>