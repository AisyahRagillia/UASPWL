<h1 style="color: whitesmoke; text-align: center;">Data Pelanggan</h1>
<table class="table table-striped table-dark table-hover">
    <tr>
        <th>No</th>
        <th>Nama Pelanggan</th>
        <th>Email</th>
        <th>Nomor Telepon</th>
        <th>Alamat</th>
        <th colspan="2" style="text-align: center;">Action</th>
    </tr>
    <?php $no = 1;
    foreach ($dataPelanggan as $row) : ?>
        <tr>
            <td><?= $no++; ?></td>
            <td><?= $row['nama']; ?></td>
            <td><?= $row['email']; ?></td>
            <td><?= $row['telepon']; ?></td>
            <td><?= $row['alamat']; ?></td>
            <td style="text-align:end;"><a href="<?= base_url('ubah/' . $row['id_pelanggan']) ?>" class="btn btn-primary">Update</a></td>
            <td><a href="<?= base_url('delete/' . $row['id_pelanggan']) ?>" class="btn btn-primary">Delete</a></td>
        </tr>
    <?php endforeach ?>
</table>
<div>
    <div class="vertical-buttons text-center">
        <a type="button" class="btn btn-secondary" href="/isi-data">Menambah Data Pelanggan</a>
        <a type="button" class="btn btn-secondary" href="/Menu">Menu</a>
        <a type="button" class="btn btn-secondary" href="/">Home</a>
        <a type="button" class="btn btn-secondary" href="/Pesan">Data Pesanan</a>

    </div>
</div>