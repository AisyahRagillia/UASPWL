<h1 style="color: whitesmoke; text-align: center;">Data Pesanan</h1>
<table class="table table-striped table-dark table-hover">
    <tr>
        <th>No</th>
        <th>Tanggal Pesanan</th>
        <th>Status Pesanan</th>
        <th>Nama Pelanggan</th>
        <th>Nomor Telepon</th>
        <th colspan="2" style="text-align: center;">Action</th>
    </tr>
    <?php $no = 1;
    foreach ($dataPesanan as $row) : ?>
        <tr>
            <td><?= $no++; ?></td>
            <td><?= $row['tgl_pesanan']; ?></td>
            <td><?= $row['status_pesanan']; ?></td>
            <td><?= $row['nama']; ?></td>
            <td><?= $row['telepon']; ?></td>
            <td style="text-align:end;"><a href="<?= base_url('ubah-pesanan/' . $row['id_pesanan']) ?>" class="btn btn-primary">Update</a></td>
            <td><a href="<?= base_url('delete-pesanan/' . $row['id_pesanan']) ?>" class="btn btn-primary">Delete</a></td>
        </tr>
    <?php endforeach ?>
</table>
<div>
    <div class="vertical-buttons text-center">
        <a type="button" class="btn btn-secondary" href="/isi-data-pesan">Menambah Data Pesanan</a>
        <a type="button" class="btn btn-secondary" href="/Menu">Menu</a>
        <a type="button" class="btn btn-secondary" href="/">Home</a>
        <a type="button" class="btn btn-secondary" href="/">Data Pelanggan</a>

    </div>
</div>