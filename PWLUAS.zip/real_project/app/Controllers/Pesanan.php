<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\get_pesanan;
use App\Models\get_pelanggan;
use App\Models\saving_pesan;

class Pesanan extends BaseController
{
    protected $pesanan;
    protected $pelanggan;

    public function __construct()
    {
        $this->pelanggan = new get_pelanggan();
        $this->pesanan = new get_pesanan();
    }
    public function index()
    {
        $data['dataPesanan'] = $this->pesanan->getPesanan();

        echo view('pages/header');
        echo view('Pesanan', $data);
        echo view('pages/footer');
    }
    public function isi()
    {
        $Pelanggan = $this->pelanggan->getpelanggan();
        $data = array(
            'dataPelanggan' => $Pelanggan,
        );


        echo view('pages/header');
        echo view('isi_pesanan', $data);
        echo view('pages/footer');
    }
    public function save()
    {
        // Ambil data dari form
        $data = [
            'tgl_pesanan' => $this->request->getPost('tanggal_pemesanan'),
            'status_pesanan' => $this->request->getPost('status_pesanan'),
            'id_pelanggan' => $this->request->getPost('id_pelanggan'),
        ];

        // Simpan data ke dalam database menggunakan model
        $save = new saving_pesan();
        $save->insertIn($data);

        // Redirect ke halaman sukses atau halaman lain setelah penyimpanan data berhasil
        return redirect()->to('/Pelanggan')->with('message', 'Data pelanggan berhasil disimpan.');
    }
    public function ubah($id)
    {
        $temp = $this->pelanggan->getpelanggan();
        $temp2 = $this->pesanan->getPesanan($id);

        $data = [
            'dataPesanan' => $temp,
            'row' => $temp2,
        ];

        echo view('pages/header');
        echo view('ubah_pesanan', $data);
        echo view('pages/footer');
    }

    public function update($id)
    {
        $model = new get_pesanan();

        $data = [
            'tgl_pesanan' => $this->request->getPost('tanggal_pemesanan'),
            'status_pesanan' => $this->request->getPost('status_pesanan'),
            'id_pelanggan' => $this->request->getPost('id_pelanggan'),
        ];

        $model->update($id, $data);
        return redirect()->to('/Pesan');
    }

    public function delete($id)
    {
        $model = new get_pesanan();
        $model->delete($id);
        return redirect()->to('/Pesan');
    }
}
