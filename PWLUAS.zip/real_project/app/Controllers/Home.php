<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\get_menu;
use App\Models\get_pelanggan;
use App\Models\get_pesanan;



class Home extends BaseController
{
    protected $makan;

    public function __construct()
    {
        $this->makan = new get_menu();
    }
    public function index()
    {
        echo view('pages/header');
        echo view('Home');
        echo view('pages/footer');
    }
    public function menu()
    {
        $Makanan = $this->makan->getmakan();
        $makan = array(
            'dataMakan' => $Makanan,
        );

        echo view('pages/header');
        echo view('Menu', $makan);
        echo view('pages/footer');
    }
}
