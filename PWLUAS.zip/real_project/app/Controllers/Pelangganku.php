<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\get_pelanggan;
use App\Models\saving;


class Pelangganku extends BaseController
{
    protected $pelanggan;

    public function __construct()
    {
        $this->pelanggan = new get_pelanggan();
    }
    public function index()
    {
        $Pelanggan = $this->pelanggan->getpelanggan();
        $data = array(
            'dataPelanggan' => $Pelanggan,
        );

        echo view('pages/header');
        echo view('Pelanggan', $data);
        echo view('pages/footer');
    }

    public function isi()
    {
        echo view('pages/header');
        echo view('isi_pelanggan');
        echo view('pages/footer');
    }
    public function save()
    {
        // Validasi input form
        $validation = \Config\Services::validation();
        $validation->setRules([
            'nama' => 'required',
            'email' => 'required|valid_email',
            'telepon' => 'required',
            'alamat' => 'required'
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            // Jika validasi gagal, kembalikan ke halaman form dengan pesan error
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        // Ambil data dari form
        $data = [
            'nama' => $this->request->getPost('nama'),
            'email' => $this->request->getPost('email'),
            'telepon' => $this->request->getPost('telepon'),
            'alamat' => $this->request->getPost('alamat')
        ];

        // Simpan data ke dalam database menggunakan model
        $customerModel = new saving();
        $customerModel->insertCustomer($data);

        // Redirect ke halaman sukses atau halaman lain setelah penyimpanan data berhasil
        return redirect()->to('/Pelanggan')->with('message', 'Data pelanggan berhasil disimpan.');
    }

    public function ubah($id)
    {
        $row['row'] = $this->pelanggan->getpelanggan($id);

        echo view('pages/header');
        echo view('ubah_pelanggan', $row);
        echo view('pages/footer');
    }

    public function update($id)
    {
        $model = new get_pelanggan();

        $data = [
            'nama' => $this->request->getPost('nama'),
            'email' => $this->request->getPost('email'),
            'telepon' => $this->request->getPost('telepon'),
            'alamat' => $this->request->getPost('alamat'),
        ];

        $model->update($id, $data);
        return redirect()->to('/Pelanggan');
    }

    public function delete($id)
    {
        $model = new get_pelanggan();
        $model->delete($id);
        return redirect()->to('/Pelanggan');
    }
}
